self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f047c187c266710fa975",
    "url": "http://0.0.0.0:8080/bundle.css"
  },
  {
    "revision": "f047c187c266710fa975",
    "url": "http://0.0.0.0:8080/bundle.js"
  },
  {
    "revision": "34523f3d34f98faf074928d41e53b01a",
    "url": "http://0.0.0.0:8080/img/profile.34523f3d.svg"
  },
  {
    "revision": "4f21394a31302d9e54fc15b8ef9324e8",
    "url": "http://0.0.0.0:8080/index.html"
  },
  {
    "revision": "cc54087102bd1d8d805c8b904d6c3395",
    "url": "http://0.0.0.0:8080/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "http://0.0.0.0:8080/robots.txt"
  }
]);