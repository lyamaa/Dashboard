self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0690e43dd11b850e80b2",
    "url": "http://0.0.0.0:8080/bundle.css"
  },
  {
    "revision": "0690e43dd11b850e80b2",
    "url": "http://0.0.0.0:8080/bundle.js"
  },
  {
    "revision": "4f21394a31302d9e54fc15b8ef9324e8",
    "url": "http://0.0.0.0:8080/index.html"
  },
  {
    "revision": "cc54087102bd1d8d805c8b904d6c3395",
    "url": "http://0.0.0.0:8080/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "http://0.0.0.0:8080/robots.txt"
  }
]);